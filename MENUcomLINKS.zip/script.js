const menu = document.querySelector('.menu')
const vermelho = document.querySelector('#vermelho')
const verde = document.querySelector('#verde')
const azul = document.querySelector('#azul')
const amarelo = document.querySelector('#amarelo')
const box = document.querySelector('.box')
const texto = document.querySelector('#texto')

vermelho.addEventListener('click', function() {
  box.style.backgroudColor = "red";
  texto.style.color = "white";
})
verde.addEventListener('click', function() {
  box.style.backgroudColor = "green";
  texto.style.color = "white";
})
azul.addEventListener('click', function() {
  box.style.backgroudColor = "blue";
  texto.style.color = "white";
})
amarelo.addEventListener('click', function() {
  box.style.backgroudColor = "yellow";
  texto.style.color = "white";
})
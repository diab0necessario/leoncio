
function calculadora(n1, n2) {
  if (typeof n1 === "number" && typeof n2 === "number") {
    const res = n1 + n2
    console.log("total: " + res)
  } else {
    console.log("ERRO")
  }
}

//calculadora (1,2)

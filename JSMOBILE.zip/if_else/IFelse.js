const idade = 18;

if (idade >= 18) {
  console.log("Maior de idade");
}

else if (idade < 18) {
  console.log("Menor de idade");
}
else {
  console.log("Idade inválida")
}

//

const cor = vermelho;
const cor = azul.

if (cor. == vermelho) {
  console.log("Imprima vermelho");
}

else if (cor == azul) {
  console.log("Imprima azul");
}
else {
  console.log("Não conheço essa cor)
}

console.log(cor.lenght);


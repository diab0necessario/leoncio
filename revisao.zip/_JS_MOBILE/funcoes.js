function dizOla() {
  alert('Olá')
}

function olaPessoa(nome) {
  alert('Olá,' nome)
}
const nome = 'Colette'
const sobrenome = 'StarPark'
const idade = '19'

function dadosPessoa() {
  const dados = nome + sobrenome + idade
   console.log(dados)
}

dizOla()
olaPessoa('Nicky')
dadosPessoa()

// # ID Ou Identificador
// . Class ou classe CSS
const comidas = document.querySelector('.comida');
// Prompt -> pergunta ao usuário (interage)
const comida1 = prompt('Digite sua comida n 1; ')
// Insere o conteúdo do usuário dentro do HTML
comidas.innerText = comida1;
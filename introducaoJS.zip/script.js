const idade = 17
const nome = 'Nicky'
const sobrenome = 'Valicoski'
const telefone = '40028922'
const casado = false


// Crie uma variável para cada um dos
// dados listados: (nome, sobrenome, telefone, casado= true or false)
// Imprima cada um dos valores com console.log(=variável=)


console.log(idade)
console.log(nome)
console.log(sobrenome)
console.log(telefone)
console.log(casado)
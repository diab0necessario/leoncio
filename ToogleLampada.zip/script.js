
const btnTrocar = document.getElementById('btn-trocar')
const lampada = document.getElementById('lampada')
let baseURL = "https://187a1f62-b522-4ac4-9e9d-8c336795119e-00-3bi4nfkgfne7u.spock.replit.dev/"

alert(lampada.src)

btnTrocar.addEventListener('click', function() {
  if (lampada.src == baseURL + "lampada0.png") {
    lampada.src = "lampada2.png"
  } else {
    lampada.src = "lampada0.png"
  }
})



// VARIÁVEIS UNITÁRIAS
const nome = 'Colette'
const nome2 = 'Edgar'
const nome3 = 'Griff'
//...

// VARIÁVEIS ARRAYS
const nomes = ['Colette', 'Edgar', 'Griff']
// IMPRIMINDO OS VALORES DO ARRAY
console.log(nomes)
conole.log(nomes[2])
nomes[10] = "Mandy" // CRIANDO DINAMICAMENTE
console.log(nomes[10])